import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-home',
    standalone: true,
    imports: [CommonModule, RouterLink],
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent {
    fullSizeImage: string | null = null;

    openFullSize(url: string) {
        this.fullSizeImage = url;
    }

    closeFullSize() {
        this.fullSizeImage = null;
    }
}
